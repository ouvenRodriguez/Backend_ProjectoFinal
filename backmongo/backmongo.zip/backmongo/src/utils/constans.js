const consts = {
  sv: { ctx: "[SERVER]" },
  ctxToken: { ctx: "[TOKEN]" },
  apiUser: "[ROUTE] [/api/user] ",
};

export default consts;
export const { sv, ctxToken, apiUser } = consts;
